"""Operators for Clone Fields."""

from pathlib import Path

import bpy
from bpy.props import FloatProperty, IntProperty, StringProperty

from . import cloner, effectors, modifier_inputs, properties, source_management


EFFECTOR_SLOT_PROPERTIES = effectors.EFFECTOR_SLOT_PROPERTIES


class CLONE_FIELDS_OT_add_cloner(bpy.types.Operator):
    bl_idname = "clone_fields.add_cloner"
    bl_label = "Add Cloner"
    bl_description = "Add a Clone Fields grid cloner"
    bl_options = {"REGISTER", "UNDO"}

    source_object_name: StringProperty(
        name=properties.SOCKET_SOURCE_OBJECT,
        description="Object to instance across the grid",
    )
    count_x: IntProperty(
        name=properties.SOCKET_COUNT_X,
        default=properties.GRID_INPUT_DEFAULTS[properties.SOCKET_COUNT_X],
        min=1,
    )
    count_y: IntProperty(
        name=properties.SOCKET_COUNT_Y,
        default=properties.GRID_INPUT_DEFAULTS[properties.SOCKET_COUNT_Y],
        min=1,
    )
    count_z: IntProperty(
        name=properties.SOCKET_COUNT_Z,
        default=properties.GRID_INPUT_DEFAULTS[properties.SOCKET_COUNT_Z],
        min=1,
    )
    spacing_x: FloatProperty(
        name=properties.SOCKET_SPACING_X,
        default=properties.GRID_INPUT_DEFAULTS[properties.SOCKET_SPACING_X],
        min=0.0,
        subtype="DISTANCE",
        unit="LENGTH",
    )
    spacing_y: FloatProperty(
        name=properties.SOCKET_SPACING_Y,
        default=properties.GRID_INPUT_DEFAULTS[properties.SOCKET_SPACING_Y],
        min=0.0,
        subtype="DISTANCE",
        unit="LENGTH",
    )
    spacing_z: FloatProperty(
        name=properties.SOCKET_SPACING_Z,
        default=properties.GRID_INPUT_DEFAULTS[properties.SOCKET_SPACING_Z],
        min=0.0,
        subtype="DISTANCE",
        unit="LENGTH",
    )

    def invoke(self, context, event):
        active = context.view_layer.objects.active
        if active is not None:
            self.source_object_name = active.name
        return self.execute(context)

    def execute(self, context):
        source_object = bpy.data.objects.get(self.source_object_name)
        if source_object is None:
            source_object = context.view_layer.objects.active
        if source_object is None:
            self.report({"ERROR"}, "Select a source object to clone")
            return {"CANCELLED"}
        if source_management.nested_cloner_depth(source_object) > (
            source_management.MAX_NESTED_CLONER_DEPTH
        ):
            self.report({"ERROR"}, "That cloner chain is too deep to clone")
            return {"CANCELLED"}

        cloner.create_grid_cloner(
            context,
            source_object=source_object,
            count_x=self.count_x,
            count_y=self.count_y,
            count_z=self.count_z,
            spacing_x=self.spacing_x,
            spacing_y=self.spacing_y,
            spacing_z=self.spacing_z,
        )

        return {"FINISHED"}


class CLONE_FIELDS_OT_add_plain_effector(bpy.types.Operator):
    bl_idname = "clone_fields.add_plain_effector"
    bl_label = "Add Basic Effector"
    bl_description = "Add a spherical Basic Effector to the active Cloner"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return _add_effector(context, self, effectors.EFFECTOR_TYPE_BASIC)


class CLONE_FIELDS_OT_add_random_effector(bpy.types.Operator):
    bl_idname = "clone_fields.add_random_effector"
    bl_label = "Add Random Effector"
    bl_description = "Add a Random Effector to the active Cloner"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return _add_effector(context, self, effectors.EFFECTOR_TYPE_RANDOM)


class CLONE_FIELDS_OT_add_target_effector(bpy.types.Operator):
    bl_idname = "clone_fields.add_target_effector"
    bl_label = "Add Target Effector"
    bl_description = "Add a Target Effector that orients clones toward its controller"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return _add_effector(context, self, effectors.EFFECTOR_TYPE_TARGET)


class CLONE_FIELDS_OT_add_shader_effector(bpy.types.Operator):
    bl_idname = "clone_fields.add_shader_effector"
    bl_label = "Add Shader Effector"
    bl_description = "Add an image-driven Shader Effector to the active Cloner"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return _add_effector(context, self, effectors.EFFECTOR_TYPE_SHADER)


class CLONE_FIELDS_OT_add_step_effector(bpy.types.Operator):
    bl_idname = "clone_fields.add_step_effector"
    bl_label = "Add Step Effector"
    bl_description = "Add a Step Effector that progresses transforms by clone order"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return _add_effector(context, self, effectors.EFFECTOR_TYPE_STEP)


class CLONE_FIELDS_OT_load_shader_image(bpy.types.Operator):
    bl_idname = "clone_fields.load_shader_image"
    bl_label = "Open Shader Image"
    bl_description = "Open an image and assign it to the selected Shader Effector"
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(
        default="*.bmp;*.cin;*.dpx;*.exr;*.hdr;*.jpeg;*.jpg;*.png;*.sgi;*.tga;*.tif;*.tiff;*.webp",
        options={"HIDDEN"},
    )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        effector_settings = _selected_shader_effector_settings(context)
        if effector_settings is None:
            self.report({"ERROR"}, "Select a Shader Effector first")
            return {"CANCELLED"}
        path = Path(self.filepath)
        if not path.is_file():
            self.report({"ERROR"}, "Choose an image file")
            return {"CANCELLED"}
        try:
            effector_settings.shader_image = bpy.data.images.load(
                str(path),
                check_existing=True,
            )
        except RuntimeError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        return {"FINISHED"}


class CLONE_FIELDS_OT_clear_shader_image(bpy.types.Operator):
    bl_idname = "clone_fields.clear_shader_image"
    bl_label = "Clear Shader Image"
    bl_description = "Unlink the image from the selected Shader Effector"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        effector_settings = _selected_shader_effector_settings(context)
        if effector_settings is None:
            return {"CANCELLED"}
        effector_settings.shader_image = None
        return {"FINISHED"}


class CLONE_FIELDS_OT_fit_shader_to_grid(bpy.types.Operator):
    bl_idname = "clone_fields.fit_shader_to_grid"
    bl_label = "Fit to Grid"
    bl_description = "Center and size the selected Shader Effector to this Grid Cloner"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cloner_object = context.object
        modifier = modifier_inputs.get_cloner_modifier(cloner_object)
        effector_settings = _selected_shader_effector_settings(context)
        if modifier is None or effector_settings is None:
            self.report({"ERROR"}, "Select a Shader Effector on a Grid Cloner")
            return {"CANCELLED"}
        if cloner_object.clone_fields_cloner.distribution_mode != "GRID":
            self.report({"ERROR"}, "Fit to Grid is available in Grid mode")
            return {"CANCELLED"}
        effector = effector_settings.id_data
        return {"FINISHED"} if effectors.fit_shader_to_grid(effector, cloner_object) else {"CANCELLED"}


class CLONE_FIELDS_OT_link_existing_effector(bpy.types.Operator):
    bl_idname = "clone_fields.link_existing_effector"
    bl_label = "Link Existing Effector"
    bl_description = "Link an existing Clone Fields Effector to the active Cloner"
    bl_options = {"REGISTER", "UNDO"}

    effector_object_name: StringProperty(
        name="Effector",
        description="Existing Clone Fields Effector to link",
    )

    def invoke(self, context, event):
        for obj in bpy.data.objects:
            if effectors.is_effector_object(obj):
                self.effector_object_name = obj.name
                break
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop_search(self, "effector_object_name", context.scene, "objects")

    def execute(self, context):
        cloner_object = context.object
        modifier = modifier_inputs.get_cloner_modifier(cloner_object)
        if modifier is None:
            self.report({"ERROR"}, "Select a Clone Fields cloner first")
            return {"CANCELLED"}

        effector = bpy.data.objects.get(self.effector_object_name)
        if not effectors.is_effector_object(effector):
            self.report({"ERROR"}, "Choose a Clone Fields Effector")
            return {"CANCELLED"}

        settings = cloner_object.clone_fields_cloner
        if _effector_already_linked(settings, effector):
            self.report({"ERROR"}, "That Effector is already linked to this Cloner")
            return {"CANCELLED"}

        slot_index = _first_empty_effector_slot(settings)
        if slot_index is None:
            self.report({"ERROR"}, "This milestone supports up to three Effectors")
            return {"CANCELLED"}

        if hasattr(effector, "clone_fields_effector"):
            shape = effector.clone_fields_effector.shape
            effector_type = effector.clone_fields_effector.type
        else:
            shape = effector.get(properties.PROP_EFFECTOR_SHAPE, effectors.FIELD_SHAPE_SPHERE)
            effector_type = effector.get(
                properties.PROP_EFFECTOR_TYPE,
                effectors.EFFECTOR_TYPE_BASIC,
            )
        _assign_effector_to_slot(
            settings,
            modifier,
            slot_index,
            effector,
            shape,
            effector_type,
        )

        bpy.ops.object.select_all(action="DESELECT")
        cloner_object.select_set(True)
        context.view_layer.objects.active = cloner_object
        return {"FINISHED"}


class CLONE_FIELDS_OT_move_plain_effector(bpy.types.Operator):
    bl_idname = "clone_fields.move_plain_effector"
    bl_label = "Move Effector"
    bl_description = "Move an Effector up or down in the Cloner stack"
    bl_options = {"REGISTER", "UNDO"}

    slot_index: IntProperty(min=0, max=2)
    direction: IntProperty(default=0)

    def execute(self, context):
        cloner_object = context.object
        if modifier_inputs.get_cloner_modifier(cloner_object) is None:
            self.report({"ERROR"}, "Select a Clone Fields cloner first")
            return {"CANCELLED"}

        target_index = self.slot_index + self.direction
        if target_index < 0 or target_index >= len(EFFECTOR_SLOT_PROPERTIES):
            return {"CANCELLED"}

        settings = cloner_object.clone_fields_cloner
        _swap_effector_slots(settings, self.slot_index, target_index)
        settings.selected_effector_slot = target_index
        _sync_all_effector_slots(settings, cloner_object.modifiers["Cloner"])
        return {"FINISHED"}


class CLONE_FIELDS_OT_select_plain_effector(bpy.types.Operator):
    bl_idname = "clone_fields.select_plain_effector"
    bl_label = "Select Effector"
    bl_description = "Show this Effector's settings"
    bl_options = {"REGISTER", "UNDO"}

    slot_index: IntProperty(min=0, max=2)

    def execute(self, context):
        cloner_object = context.object
        if modifier_inputs.get_cloner_modifier(cloner_object) is None:
            self.report({"ERROR"}, "Select a Clone Fields cloner first")
            return {"CANCELLED"}

        cloner_object.clone_fields_cloner.selected_effector_slot = self.slot_index
        _tag_view3d_redraw(context)
        return {"FINISHED"}


class CLONE_FIELDS_OT_select_effector_object(bpy.types.Operator):
    bl_idname = "clone_fields.select_effector_object"
    bl_label = "Select Effector Object"
    bl_description = "Select this Effector in the scene for moving or animation"
    bl_options = {"REGISTER", "UNDO"}

    slot_index: IntProperty(min=0, max=2)

    def execute(self, context):
        cloner_object = context.object
        if modifier_inputs.get_cloner_modifier(cloner_object) is None:
            self.report({"ERROR"}, "Select a Clone Fields cloner first")
            return {"CANCELLED"}

        settings = cloner_object.clone_fields_cloner
        settings.selected_effector_slot = self.slot_index
        _tag_view3d_redraw(context)
        effector = getattr(settings, EFFECTOR_SLOT_PROPERTIES[self.slot_index]["object"])
        if effector is None:
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        effector.select_set(True)
        context.view_layer.objects.active = effector
        return {"FINISHED"}


def _tag_view3d_redraw(context) -> None:
    screen = getattr(context, "screen", None)
    if screen is None:
        return
    for area in screen.areas:
        if area.type == "VIEW_3D":
            area.tag_redraw()


class CLONE_FIELDS_OT_delete_effector(bpy.types.Operator):
    bl_idname = "clone_fields.delete_effector"
    bl_label = "Delete Effector"
    bl_description = "Remove this Effector from the stack and delete its scene object"
    bl_options = {"REGISTER", "UNDO"}

    slot_index: IntProperty(min=0, max=2)

    def execute(self, context):
        cloner_object = context.object
        if modifier_inputs.get_cloner_modifier(cloner_object) is None:
            self.report({"ERROR"}, "Select a Clone Fields cloner first")
            return {"CANCELLED"}

        settings = cloner_object.clone_fields_cloner
        slot = EFFECTOR_SLOT_PROPERTIES[self.slot_index]
        effector = getattr(settings, slot["object"])
        if effector is None:
            return {"CANCELLED"}

        for index in range(self.slot_index, len(EFFECTOR_SLOT_PROPERTIES) - 1):
            _copy_effector_slot(settings, index + 1, index)
        _clear_effector_slot(settings, len(EFFECTOR_SLOT_PROPERTIES) - 1)
        _sync_all_effector_slots(settings, cloner_object.modifiers["Cloner"])

        if not _is_effector_referenced(effector) and effector.name in bpy.data.objects:
            bpy.data.objects.remove(effector, do_unlink=True)

        settings.selected_effector_slot = _nearest_used_effector_slot(
            settings,
            min(self.slot_index, len(EFFECTOR_SLOT_PROPERTIES) - 1),
        )
        bpy.ops.object.select_all(action="DESELECT")
        cloner_object.select_set(True)
        context.view_layer.objects.active = cloner_object
        return {"FINISHED"}


classes = (
    CLONE_FIELDS_OT_add_cloner,
    CLONE_FIELDS_OT_add_plain_effector,
    CLONE_FIELDS_OT_add_random_effector,
    CLONE_FIELDS_OT_add_target_effector,
    CLONE_FIELDS_OT_add_shader_effector,
    CLONE_FIELDS_OT_add_step_effector,
    CLONE_FIELDS_OT_load_shader_image,
    CLONE_FIELDS_OT_clear_shader_image,
    CLONE_FIELDS_OT_fit_shader_to_grid,
    CLONE_FIELDS_OT_link_existing_effector,
    CLONE_FIELDS_OT_move_plain_effector,
    CLONE_FIELDS_OT_select_plain_effector,
    CLONE_FIELDS_OT_select_effector_object,
    CLONE_FIELDS_OT_delete_effector,
)


def _selected_shader_effector_settings(context):
    cloner_object = context.object
    if modifier_inputs.get_cloner_modifier(cloner_object) is None:
        return None
    settings = cloner_object.clone_fields_cloner
    index = settings.selected_effector_slot
    if index < 0 or index >= len(EFFECTOR_SLOT_PROPERTIES):
        return None
    effector = getattr(settings, EFFECTOR_SLOT_PROPERTIES[index]["object"])
    if not effectors.is_effector_object(effector):
        return None
    effector_settings = getattr(effector, "clone_fields_effector", None)
    if (
        effector_settings is None
        or effector_settings.type != effectors.EFFECTOR_TYPE_SHADER
    ):
        return None
    return effector_settings


def _first_empty_effector_slot(settings) -> int | None:
    for index, slot_properties in enumerate(EFFECTOR_SLOT_PROPERTIES):
        if getattr(settings, slot_properties["object"]) is None:
            return index
    return None


def _assign_effector_to_slot(
    settings,
    modifier,
    slot_index: int,
    effector: bpy.types.Object,
    shape: str,
    effector_type: str,
) -> None:
    slot_properties = EFFECTOR_SLOT_PROPERTIES[slot_index]
    _reset_effector_slot(settings, slot_index)
    setattr(settings, slot_properties["type"], effector_type)
    setattr(settings, slot_properties["shape"], shape)
    setattr(settings, slot_properties["object"], effector)
    setattr(settings, slot_properties["enabled"], True)
    settings.selected_effector_slot = slot_index
    effectors.sync_effector_slot(settings, modifier, slot_index)


def _effector_already_linked(settings, effector: bpy.types.Object) -> bool:
    return any(
        getattr(settings, slot["object"]) == effector
        for slot in EFFECTOR_SLOT_PROPERTIES
    )


def _reset_effector_slot(settings, slot_index: int) -> None:
    slot_properties = EFFECTOR_SLOT_PROPERTIES[slot_index]
    socket_set = properties.EFFECTOR_SOCKET_SETS[slot_index]
    for key, property_name in slot_properties.items():
        if key in {"object", "shape"}:
            continue
        if key == "strength":
            default = properties.EFFECTOR_STRENGTH_PERCENT_DEFAULT
        elif key == "type":
            default = effectors.EFFECTOR_TYPE_BASIC
        elif key == "target_axis":
            default = "Z"
        elif key == "target_up_axis":
            default = "Y"
        elif key == "target_object":
            default = None
        else:
            default = properties.GRID_INPUT_DEFAULTS[socket_set[key]]
        setattr(settings, property_name, default)


def _clear_effector_slot(settings, slot_index: int) -> None:
    slot_properties = EFFECTOR_SLOT_PROPERTIES[slot_index]
    setattr(settings, slot_properties["object"], None)
    setattr(settings, slot_properties["type"], effectors.EFFECTOR_TYPE_BASIC)
    setattr(settings, slot_properties["shape"], effectors.FIELD_SHAPE_SPHERE)
    _reset_effector_slot(settings, slot_index)


def _copy_effector_slot(settings, source_index: int, target_index: int) -> None:
    source = EFFECTOR_SLOT_PROPERTIES[source_index]
    target = EFFECTOR_SLOT_PROPERTIES[target_index]
    keys = ("shape", "object") + tuple(
        key for key in source if key not in {"shape", "object"}
    )
    for key in keys:
        setattr(settings, target[key], getattr(settings, source[key]))


def _nearest_used_effector_slot(settings, start_index: int) -> int:
    for index in range(start_index, len(EFFECTOR_SLOT_PROPERTIES)):
        if getattr(settings, EFFECTOR_SLOT_PROPERTIES[index]["object"]) is not None:
            return index
    for index in range(start_index - 1, -1, -1):
        if getattr(settings, EFFECTOR_SLOT_PROPERTIES[index]["object"]) is not None:
            return index
    return 0


def _is_effector_referenced(effector: bpy.types.Object) -> bool:
    for obj in bpy.data.objects:
        if modifier_inputs.get_cloner_modifier(obj) is None:
            continue
        settings = obj.clone_fields_cloner
        if _effector_already_linked(settings, effector):
            return True
    return False


def _swap_effector_slots(settings, first_index: int, second_index: int) -> None:
    first = EFFECTOR_SLOT_PROPERTIES[first_index]
    second = EFFECTOR_SLOT_PROPERTIES[second_index]
    values = {key: getattr(settings, first[key]) for key in first}
    for key in first:
        setattr(settings, first[key], getattr(settings, second[key]))
    for key, value in values.items():
        setattr(settings, second[key], value)


def _sync_all_effector_slots(settings, modifier) -> None:
    for index, slot in enumerate(EFFECTOR_SLOT_PROPERTIES):
        if getattr(settings, slot["object"]) is None:
            continue
        effectors.sync_effector_slot(settings, modifier, index)


def _add_effector(context, operator, effector_type: str):
    cloner_object = context.object
    modifier = modifier_inputs.get_cloner_modifier(cloner_object)
    if modifier is None:
        operator.report({"ERROR"}, "Select a Clone Fields cloner first")
        return {"CANCELLED"}

    settings = cloner_object.clone_fields_cloner
    slot_index = _first_empty_effector_slot(settings)
    if slot_index is None:
        operator.report({"ERROR"}, "This milestone supports up to three Effectors")
        return {"CANCELLED"}

    slot_properties = EFFECTOR_SLOT_PROPERTIES[slot_index]
    shape = (
        effectors.FIELD_SHAPE_NONE
        if effector_type in {
            effectors.EFFECTOR_TYPE_RANDOM,
            effectors.EFFECTOR_TYPE_TARGET,
            effectors.EFFECTOR_TYPE_SHADER,
            effectors.EFFECTOR_TYPE_STEP,
        }
        else getattr(settings, slot_properties["shape"])
    )
    radius = properties.GRID_INPUT_DEFAULTS[
        properties.EFFECTOR_SOCKET_SETS[slot_index]["radius"]
    ]
    effector = bpy.data.objects.new(effectors.effector_name(effector_type, shape), None)
    effectors.configure_effector_object(
        effector,
        shape,
        radius,
        effector_type,
        box_size=(
            properties.GRID_INPUT_DEFAULTS[properties.EFFECTOR_SOCKET_SETS[slot_index]["box_x"]],
            properties.GRID_INPUT_DEFAULTS[properties.EFFECTOR_SOCKET_SETS[slot_index]["box_y"]],
            properties.GRID_INPUT_DEFAULTS[properties.EFFECTOR_SOCKET_SETS[slot_index]["box_z"]],
        ),
    )
    context.collection.objects.link(effector)
    if hasattr(effector, "clone_fields_effector"):
        effector.clone_fields_effector.type = effector_type
        effector.clone_fields_effector.shape = shape
        effector.clone_fields_effector.radius = radius
        if effector_type == effectors.EFFECTOR_TYPE_RANDOM:
            effector.clone_fields_effector.use_position = True
            effector.clone_fields_effector.position_x = 0.25
            effector.clone_fields_effector.position_y = 0.25
            effector.clone_fields_effector.position_z = 0.25
            effector.clone_fields_effector.use_rotation = False
            effector.clone_fields_effector.use_scale = False
        elif effector_type == effectors.EFFECTOR_TYPE_TARGET:
            effector.clone_fields_effector.use_position = False
            effector.clone_fields_effector.use_rotation = True
            effector.clone_fields_effector.use_scale = False
            effector.clone_fields_effector.target_axis = "Z"
            effector.clone_fields_effector.target_up_axis = "Y"
        elif effector_type == effectors.EFFECTOR_TYPE_SHADER:
            effector.clone_fields_effector.use_position = True
            effector.clone_fields_effector.position_z = 1.0
            effector.clone_fields_effector.use_rotation = False
            effector.clone_fields_effector.use_scale = False
        elif effector_type == effectors.EFFECTOR_TYPE_STEP:
            effector.clone_fields_effector.use_position = True
            effector.clone_fields_effector.position_z = 1.0
            effector.clone_fields_effector.use_rotation = False
            effector.clone_fields_effector.use_scale = False
    effector.location = cloner_object.location
    if effector_type == effectors.EFFECTOR_TYPE_TARGET:
        effector.location.z += 3.0

    _assign_effector_to_slot(settings, modifier, slot_index, effector, shape, effector_type)

    bpy.ops.object.select_all(action="DESELECT")
    cloner_object.select_set(True)
    context.view_layer.objects.active = cloner_object
    return {"FINISHED"}


def register() -> None:
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister() -> None:
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
